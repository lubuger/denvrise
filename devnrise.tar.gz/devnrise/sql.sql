create table users
(
    id       serial
        constraint users_pk
            primary key,
    name     varchar(100) not null,
    email    varchar(100) not null,
    password varchar(255) not null
);

create unique index users_email_index
    on users (email);

create unique index users_id_index
    on users (id);

