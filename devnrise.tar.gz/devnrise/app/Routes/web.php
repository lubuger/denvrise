<?php

return [
  '/' => 'IndexController@loginView',
  '/register' => 'IndexController@registerView',
  '/profile' => 'IndexController@profileView',

  '/do-login' => 'IndexController@doLogin',
  '/do-register' => 'IndexController@doRegister',
];