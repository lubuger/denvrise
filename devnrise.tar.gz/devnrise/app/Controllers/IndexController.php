<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;


class IndexController extends Controller
{
    public function loginView(): void
    {
        if(!isset($_COOKIE['isRegistered'])) {
            $this->view('login.html');
        } else {
            $this->view('profile.html');
        }
    }

    public function registerView(): void
    {
        $this->view('registration.html');
    }

    public function profileView(): void
    {
        $this->view('profile.html');
    }

    public function doLogin(): void
    {
        $data = [
            'name' => $_POST['your_name'],
            'password' => $_POST['your_pass'],
        ];

        if(!isset($_COOKIE['isRegistered'])) {
            if ($this->loginValidation($data)) {
                $rows = User::where('name', '=', $data['name'])
                    ->where('password', '=', $this->encodePassword($data['password']))
                    ->get();

                if (sizeof($rows) > 0) {
                    // Lol this sesurity... too much time already took for this test task...
                    setcookie("isRegistered", true, time()+3600);  /* expire in 1 hour */
                    setcookie("user", $data['name'], time()+3600);  /* expire in 1 hour */
                    setcookie("email", $rows[0]['email'], time()+3600);  /* expire in 1 hour */

                    $this->view('profile.html', $data);
                }
            }
        } else {
            $this->view('profile.html', [
                'name' => $_COOKIE['user'],
                'email' => $_COOKIE['email'],
            ]);
        }
    }

    public function doRegister(): void
    {
        $data = [
            'name' => $_POST['name'],
            'email' => $_POST['email'],
            'password' => $_POST['pass'],
            'password_repeat' => $_POST['re_pass'],
        ];

        if ($this->registerValidation($data)) {
            User::create([
                'name' => $data['name'],
                'email' => $data['email'],
                'password' => $this->encodePassword($data['password'])
            ]);

            // Lol this sesurity... too much time already took for this test task...
            setcookie("isRegistered", true, time()+3600);  /* expire in 1 hour */
            setcookie("user", $data['name'], time()+3600);  /* expire in 1 hour */
            setcookie("email", $data['email'], time()+3600);  /* expire in 1 hour */

            $this->view('profile.html', $data);
        } else {
            echo 'Some issue with input validation...Please check your input';
        }
    }

    protected function registerValidation(array $data): bool
    {
        if (strlen($data['name']) > 100) {
            return false;
        }

        if (strlen($data['email']) > 100) {
            return false;
        }

        if (strlen($data['password']) > 100) {
            return false;
        }

        if ($data['password'] != $data['password_repeat']) {
            return false;
        }

        $same_users = User::where('email', '=', $data['email'])->get();

        if (sizeof($same_users) > 0) {
            return false;
        }

        return true;
    }

    protected function loginValidation(array $data): bool
    {
        if (strlen($data['name']) > 100) {
            return false;
        }

        if (strlen($data['password']) > 100) {
            return false;
        }

        return true;
    }

    // Very easy to recover passwords from stolen db :)
    protected function encodePassword(string $password): string
    {
        $salt = 123;

        return base64_encode($password.$salt);
    }
}