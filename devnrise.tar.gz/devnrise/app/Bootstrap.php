<?php

namespace App;

use App\Core\Bootstrap as CoreBootstrap;


class Bootstrap {
    protected $dirs = [
        'config' => '/Config',
        'core' => '/Core',
        'controllers' => '/Controllers',
        'routes' => '/Routes',
        'models' => '/Models',
        'enums' => '/Enums',
    ];
    protected CoreBootstrap $CoreBootstrap;
    protected array $DB;
    protected array $routes = [];

    public function __construct()
    {
        foreach ($this->dirs as $dir) {
            $this->includeFiles(__DIR__.$dir);
        }

        $this->CoreBootstrap = new CoreBootstrap([
            'database' => $this->DB,
            'routes' => $this->routes,
        ]);
    }

    public function includeFiles(string $dir): void
    {
        $files = scandir($dir);

        foreach ($files as $file) {
            if ($file != '.' && $file != '..') {
                $path = $dir.'/'.$file;

                if (str_contains($file, 'database')) {
                    $this->DB = require_once $path;
                } else if (str_contains($dir, 'Routes')) {
                    $this->routes = array_merge($this->routes, require_once $path);
                } else {
                    require_once $path;
                }
            }
        }
    }
}