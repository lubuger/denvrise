<?php

namespace App\Core;


class Bootstrap
{
    public Database $db;
    protected Router $router;

    public function __construct(array $props)
    {
        $this->db = new Database($props['database']);
        $this->router = new Router($props, $this->db->db_PDO);
    }
}