<?php

namespace App\Core;


class Controller
{
    protected function view(string $file, array $variables = []): void
    {
        $full_path = getcwd().'/public/'.$file;
        $content = file_get_contents($full_path);

        $content = preg_replace('/href="/', 'href="/public/', $content);
        $content = preg_replace('/src="/', 'src="/public/', $content);

        header('Content-Type: text/html; charset=utf-8');
        header('Content-Length: ' . filesize($full_path));

        echo $content;
    }
}