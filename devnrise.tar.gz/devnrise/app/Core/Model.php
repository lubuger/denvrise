<?php

namespace App\Core;


class Model
{
    protected static $table;
    protected $fillable = [];
    protected static array $data = [];

    public function __construct() { }

    protected static function getConn()
    {
        $traces = debug_backtrace();
        $conn = false;

        foreach ($traces as $trace) {
            if ($trace['class'] === 'App\Core\Bootstrap') {
                $conn = $trace['object']->db->db_PDO;
                break;
            }
        }

        return $conn;
    }

    public static function create(array $data)
    {
        $conn = self::getConn();
        $parent = get_called_class();
        $parent = new $parent();
        $table = $parent::$table;

        if ($conn) {
            $vars = implode(', ', array_keys($data));
            $inserts = implode(', ', array_fill(0, sizeof($data), '?'));
            $sql = sprintf("INSERT INTO $table ($vars) VALUES ($inserts)");
            $stmt = $conn->prepare($sql);

            $stmt->execute(array_values($data));
        }
    }

    public static function get(): array
    {
        return self::$data;
    }

    public function __call($name, $arguments)
    {
        if ($name === 'where') {
            $conn = $this->getConn();
            $parent = get_called_class();
            $parent = new $parent();
            $table = $parent::$table;

            if ($conn) {
                $sql = false;

                if (sizeof($arguments) > 2) {
                    $sql = sprintf("SELECT * FROM $table WHERE $arguments[0] $arguments[1] :which ORDER BY id");
                } else {
                    $sql = sprintf("SELECT * FROM $table WHERE $arguments[0] :which ORDER BY id");
                }

                $stmt = $conn->prepare($sql);
                $stmt->execute(array('which' => $arguments[2]));

                $rows = [];
                foreach ($stmt as $row) {
                    $rows[] = $row;
                }

                self::$data = $rows;

                return $this;
            }
        }
    }

    public static function __callStatic($name, $arguments)
    {
        static $instance;
        if ($instance === null)
            $instance = new Model();

        if ($name === 'where') {
            $conn = self::getConn();
            $parent = get_called_class();
            $parent = new $parent();
            $table = $parent::$table;
            self::$table = $table;

            if ($conn) {
                $sql = false;

                if (sizeof($arguments) > 2) {
                    $sql = sprintf("SELECT * FROM $table WHERE $arguments[0] $arguments[1] :which ORDER BY id");
                } else {
                    $sql = sprintf("SELECT * FROM $table WHERE $arguments[0] :which ORDER BY id");
                }

                $stmt = $conn->prepare($sql);
                $stmt->execute(array('which' => $arguments[2]));

                $rows = [];
                foreach ($stmt as $row) {
                    $rows[] = $row;
                }

                self::$data = $rows;

                return $instance;
            }
        }
    }
}