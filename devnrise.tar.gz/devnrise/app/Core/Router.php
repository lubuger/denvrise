<?php

namespace App\Core;


class Router
{
    protected string $URI;
    protected array $routes;

    public function __construct(array $props)
    {
        $this->URI = $_SERVER['REQUEST_URI'];
        $this->routes = $props['routes'];

        foreach ($this->routes as $route => $controller) {
            if ($this->URI === $route) {
                $route_slices = str_split($controller, strpos($controller, '@'));
                $ctrl = '\App\Controllers\\'
                    .$route_slices[0];
                $ctrl_method = substr($route_slices[1], 1);

                if (class_exists($ctrl)) {
                    $ctrl = new $ctrl();

                    if (is_callable(array($ctrl, $ctrl_method))) {
                        $ctrl->{$ctrl_method}();
                    } else {
                        echo 'Router callable method do not exists';
                    }
                } else {
                    echo 'Router callable class do not exists';
                }
            }
        }
    }
}