<?php

namespace App\Core;


class Database
{
    public \PDO $db_PDO;

    public function __construct(array $props)
    {
        try {
            $this->db_PDO = new \PDO(
                'pgsql:host='.$props['host'].';dbname='.$props['database'],
                $props['username'],
                $props['password']
            );
        } catch (\Exception $e) {
            die("<b>Error:</b> $e");
        }
    }
}