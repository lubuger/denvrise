<?php

namespace App\Config;

return [
    'host' => '127.0.0.1',
    'port' => '5432',
    'database' => 'denvrise',
    'username' => 'dbuser',
    'password' => 'Us3RpOstg3s',
];