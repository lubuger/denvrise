<?php

include_once 'app/Bootstrap.php';

use App\Bootstrap;

$core = new Bootstrap();